Columns with empty or redundant data were removed.
Only Rows from the current conflicts are left. Data before Oct 7,2023 were removed.